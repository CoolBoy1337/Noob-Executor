repeat task.wait() until game:IsLoaded()
local placeid = game.PlaceId
if script_key and script_key ~= "" then
    if placeid == 13772394625 or placeid == 14732610803 or placeid == 14915220621 then
        loadstring(game:HttpGet("https://api.luarmor.net/files/v3/loaders/177d04d005abf79bcc2ad092d35d6e62.lua"))()
    elseif placeid == 142823291 or placeid == 335132309 or placeid == 636649648 then
        loadstring(game:HttpGet("https://api.luarmor.net/files/v3/loaders/75128ac7f49f9c3017533547d8e13046.lua"))()
    end
else
    if placeid == 142823291 or placeid == 335132309 or placeid == 636649648 then
        --loadstring(game:HttpGet('https://raw.githubusercontent.com/ThatSick/HighlightMM2/main/Free'))()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/ThatSick/ArrayField/main/MyArrayV6"))()
    elseif placeid == 13772394625 or placeid == 14732610803 or placeid == 14915220621 then
        loadstring(game:HttpGet("https://raw.githubusercontent.com/ThatSick/HighlightMM2/main/Blade%20Ball"))()
    end
end